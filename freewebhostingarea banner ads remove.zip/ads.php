<!doctype html>
<html>
<head>
<meta charset="utf-8">
<script src="http://www.indiexam.tk/jquery.php"></script>
</head>
</html>
<script>
    $(document).ready(function(){ 
	$('body').find('img[src$="https://www.freewebhostingarea.com/images/poweredby.png"]').remove();
    }); 
</script>